package com.onlinebanking.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;


















import Exception.OnlineBankingException;

















import com.onlinebanking.Bean.OnlineBankingBean;
//import com.onlinebanking.Exception.OnlineBankingException;
import com.onlinebanking.Util.DBUtil;

public class OnlineBankingDao implements IonlineBankingDao{

	@Override
	public ArrayList<Long> getAccounts(long acc_no) throws OnlineBankingException {
		Connection con=null;
		PreparedStatement st=null;
		ResultSet rs=null;
		long user_id=0;
		String pwd=null;
		long account_no=0;
		ArrayList<Long> accounts=new ArrayList<Long>();
		
		try{
			System.out.println("hello");
			con=DBUtil.obtainConnection();
			//stmt=con.createStatement();
			//rs=stmt.executeQuery("select account_no,user_id,login_password from user_table where user_id='"+userId+"' and login_password='"+password+"'");
			st=con.prepareStatement(IQueryMapper.GET_ACCOUNTS);
			st.setLong(1, acc_no);
			System.out.println("hello");
			rs=st.executeQuery();
			System.out.println("hello");
		
			if(rs!=null){
				while(rs.next()){
					
					user_id=rs.getLong(2);
					pwd=rs.getString(3);
					account_no=rs.getLong(1);
					accounts.add(account_no);
				}
			}			
		}
		catch(OnlineBankingException e){
			throw new OnlineBankingException("details not fetched");
		}
		catch(Exception e){
			throw new OnlineBankingException("DataBase error");
		}
		return accounts;
	}

	@Override
	public String getEmailId(long accountNo) {
		Connection con=null;
		PreparedStatement st=null;
		ResultSet rs=null;
		String email=null;
		try{
			con=DBUtil.obtainConnection();
			st=con.prepareStatement(IQueryMapper.GET_EMAIL);
			st.setLong(1, accountNo);
			rs=st.executeQuery();
			if(rs!=null){
				while(rs.next()){
					email=rs.getString(1);
				}
			}
			if(email==null){
				throw new OnlineBankingException("Email Not Found");
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return email;
	}

	@Override
	public String getEmailId(long acc_no, String email, String existingemail) {
		Connection con=null;
		PreparedStatement st=null;
		ResultSet rs=null;
		String updateEmail = null;
		try{
			con=DBUtil.obtainConnection();
			st=con.prepareStatement(IQueryMapper.UPDATE_EMAIL);
			st.setString(1, email);
			st.setLong(2, acc_no);
			st.setString(3, existingemail);
			int records=st.executeUpdate();
			if(records>0){
				updateEmail="Updated";
			}
			else{
				throw new OnlineBankingException("Email Not Updated");
			}
			
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return updateEmail;
	}

	@Override
	public String getAddress(long accountNo) {
		Connection con=null;
		PreparedStatement st=null;
		ResultSet rs=null;
		String address=null;
		try{
			con=DBUtil.obtainConnection();
			st=con.prepareStatement(IQueryMapper.GET_ADDRESS);
			st.setLong(1, accountNo);
			rs=st.executeQuery();
			if(rs!=null){
				while(rs.next()){
					address=rs.getString(1);
				}
			}
			if(address==null){
				throw new OnlineBankingException("address Not Found");
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return address;
	}
	@Override
	public String getAddressUpdate(long acc_no, String address, String existingAddress) {
		Connection con=null;
		PreparedStatement st=null;
		ResultSet rs=null;
		String updateAddress = null;
		try{
			con=DBUtil.obtainConnection();
			st=con.prepareStatement(IQueryMapper.UPDATE_ADDRESS);
			st.setString(1, address);
			st.setLong(2, acc_no);
			st.setString(3, existingAddress);
			int records=st.executeUpdate();
			if(records>0){
				updateAddress="Updated";
			}
			else{
				throw new OnlineBankingException("Address Not Updated");
			}
			
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return updateAddress;
	}

	@Override
	public String raiseCheckBookRequest(long accountNo, String description) {
		Connection con=null;
		Statement stmt=null;
		PreparedStatement pmstmt=null;
		long service_id=0;
		String CheckBookRequest=null;
		try{
			con=DBUtil.obtainConnection();
			pmstmt=con.prepareStatement(IQueryMapper.SER_SEQ_ID);
			ResultSet rs=pmstmt.executeQuery();
			System.out.println("hello");
			if(rs!=null){
				while(rs.next()){
					service_id=rs.getLong(1);
				}
			}
			pmstmt=con.prepareStatement(IQueryMapper.RAISECHECKBOOK);
			pmstmt.setLong(1, service_id);
			pmstmt.setString(2, description);
			pmstmt.setLong(3, accountNo);
			pmstmt.setString(4,"Open State");
			int records=pmstmt.executeUpdate();
			System.out.println("hello");
			if(records>0){
				CheckBookRequest=Long.toString(service_id);
				
			}
			else{
				throw new OnlineBankingException("Records not updated");
			}
			
			
			
		}
		catch(Exception e){
			//throw new OnlineBankingException("Update Failed");
			e.printStackTrace();
		}
		return CheckBookRequest;
	}

	@Override
	public ArrayList<OnlineBankingBean> getServiceRequestDetails(long service_id) {
		Connection con=null;
		Statement stmt=null;
		PreparedStatement pmstmt=null;
		ResultSet rs=null;
		long serviceId=0;
		ArrayList<OnlineBankingBean> serviceRequest=new ArrayList<OnlineBankingBean>();
		try{
			con=DBUtil.obtainConnection();
			pmstmt=con.prepareStatement(IQueryMapper.SERVICE_REQUEST_DETAILS);
			pmstmt.setLong(1, service_id);
			rs=pmstmt.executeQuery();
			if(rs!=null){
				while(rs.next()){
					serviceId=rs.getLong(1);
					OnlineBankingBean b=new OnlineBankingBean();
					b.setServiceId(rs.getLong(1));
					b.setService_description(rs.getString(2));
					b.setAccountNo(rs.getLong(3));
					b.setService_date(rs.getString(4));
					b.setService_status(rs.getString(5));
					
					serviceRequest.add(b);
					
				}
			}
			if(serviceId==0){
				throw new OnlineBankingException("Details not found");
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return serviceRequest;
	}
	@Override
	public ArrayList<Long> getPayeeAccounts(long uid) {
		Connection con=null;
		PreparedStatement pmstmt=null;
		ResultSet rs=null;
		Statement stmt=null;
		ArrayList<Long> payeeAccounts=new ArrayList<Long>();
		try{
			con=DBUtil.obtainConnection();
			pmstmt=con.prepareStatement(IQueryMapper.payeeAccounts);
			pmstmt.setLong(1, uid);
			rs=pmstmt.executeQuery();
			if(rs!=null){
				while(rs.next()){
					payeeAccounts.add(rs.getLong(1));
				}
			}
		}
		catch(Exception e){
			
		}
		return payeeAccounts;
	}

	@Override
	public String transferFunds(long accountNo, long payeeAccount,
			String transferDesc,long amount,String transpwd) {
		Connection con=null;
		PreparedStatement pmstmt=null;
		ResultSet rs=null;
		Statement stmt=null;
		long UserBalanceAmount = 0;
		long PayeeBalanceAmount = 0;
		long userTransactionId = 0;
		long payeeTransactionId = 0;
		String transaction=null;
		String transaction_password=null;
		try{
			con=DBUtil.obtainConnection();
			pmstmt=con.prepareStatement(IQueryMapper.transaction_password);
			pmstmt.setLong(1, accountNo);
			rs=pmstmt.executeQuery();
			if(rs!=null){
				while(rs.next()){
					transaction_password=rs.getString(1);
				}
			}
			if(transpwd.equals(transaction_password)){
			pmstmt=con.prepareStatement(IQueryMapper.accountBalance);
			pmstmt.setLong(1, accountNo);
			rs=pmstmt.executeQuery();
			if(rs!=null){
				while(rs.next()){
					UserBalanceAmount=rs.getLong(1);
				}
			}
			pmstmt=con.prepareStatement(IQueryMapper.accountBalance);
			pmstmt.setLong(1, payeeAccount);
			rs=pmstmt.executeQuery();
			if(rs!=null){
				while(rs.next()){
					PayeeBalanceAmount=rs.getLong(1);
				}
			}
			pmstmt=con.prepareStatement(IQueryMapper.updateUserAccount);
			long debitedAmount=UserBalanceAmount-amount;
			pmstmt.setLong(1, debitedAmount);
			pmstmt.setLong(2, accountNo);
			int records=pmstmt.executeUpdate();
			if(records>0){
				pmstmt=con.prepareStatement(IQueryMapper.updateUserAccount);
				long creditedAmount=PayeeBalanceAmount+amount;
				pmstmt.setLong(1, creditedAmount);
				pmstmt.setLong(2, payeeAccount);
				int result=pmstmt.executeUpdate();
				if(result>0){
					stmt=con.createStatement();
					rs=stmt.executeQuery(IQueryMapper.transaction_id);
					if(rs!=null){
						while(rs.next()){
							userTransactionId=rs.getLong(1);
						}
					}
					pmstmt=con.prepareStatement(IQueryMapper.updateUserTransaction);
					pmstmt.setLong(1, userTransactionId);
					pmstmt.setString(2, transferDesc);
					pmstmt.setString(3,"D");
					pmstmt.setLong(4, amount);
					pmstmt.setLong(5, payeeAccount);
					int transInsertion=pmstmt.executeUpdate();
					if(transInsertion>0){
						stmt=con.createStatement();
						rs=stmt.executeQuery(IQueryMapper.transaction_id);
						if(rs!=null){
							while(rs.next()){
								payeeTransactionId=rs.getLong(1);
							}
						}
						
						pmstmt=con.prepareStatement(IQueryMapper.updateUserTransaction);
						pmstmt.setLong(1, payeeTransactionId);
						pmstmt.setString(2, transferDesc);
						pmstmt.setString(3,"C");
						pmstmt.setLong(4, amount);
						pmstmt.setLong(5, payeeAccount);
						int payeeTransInsertion=pmstmt.executeUpdate();
						if(payeeTransInsertion>0){
							transaction="success";
						}
						else{
							transaction="failed";
						}
					}
					else{
						transaction="failed";
					}
				}
				else{
					transaction="failed";
				}
			}
			else{
				transaction="failed";
			}
			}
			else{
				transaction="failed";
			}
			
			
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return transaction;
	}

	@Override
	public ArrayList<OnlineBankingBean> getAccountServiceRequestDetails(
			long acc_no) {
		Connection con=null;
		Statement stmt=null;
		PreparedStatement pmstmt=null;
		ResultSet rs=null;
		long serviceId=0;
		ArrayList<OnlineBankingBean> serviceRequest=new ArrayList<OnlineBankingBean>();
		try{
			con=DBUtil.obtainConnection();
			pmstmt=con.prepareStatement(IQueryMapper.AccountServiceDetails);
			pmstmt.setLong(1, acc_no);
			System.out.println("hello");
			rs=pmstmt.executeQuery();
			System.out.println("hello");
			if(rs!=null){
				while(rs.next()){
					//serviceId=rs.getLong(1);
					OnlineBankingBean b=new OnlineBankingBean();
					b.setServiceId(rs.getLong(1));
					b.setService_description(rs.getString(2));
					b.setAccountNo(rs.getLong(3));
					b.setService_date(rs.getString(4));
					b.setService_status(rs.getString(5));
					
					serviceRequest.add(b);
					
				}
			}
			if(serviceId==0){
				throw new OnlineBankingException("Details not found");
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return serviceRequest;
	}

	@Override
	public String createAccount(OnlineBankingBean ob) {
		Connection con=null;
		Statement stmt=null;
		PreparedStatement pmstmt=null;
		ResultSet rs=null;
		long accountNo=0;
		String account=null;
		try{
			con=DBUtil.obtainConnection();
			pmstmt=con.prepareStatement(IQueryMapper.AccountSequence);
			rs=pmstmt.executeQuery();
			if(rs!=null){
				while(rs.next()){
					accountNo=rs.getLong(1);
				}
			}
			pmstmt=con.prepareStatement(IQueryMapper.CreateAccount);
			pmstmt.setLong(1, accountNo);
			pmstmt.setString(2, ob.getAccountType());
			pmstmt.setLong(3, ob.getOpeningBalance());
			int records=pmstmt.executeUpdate();
			if(records>0){
				pmstmt=con.prepareStatement(IQueryMapper.customerDetails);
				pmstmt.setLong(1, accountNo);
				pmstmt.setString(2, ob.getName());
				pmstmt.setString(3, ob.getEmailId());
				pmstmt.setString(4, ob.getAddress());
				pmstmt.setString(5, ob.getPanno());
				int customer=pmstmt.executeUpdate();
				if(customer>0){
					account=Long.toString(accountNo);
				}
				else{
					throw new OnlineBankingException("Account Not Created");
				}
			}
			else{
				throw new OnlineBankingException("Account Not Created");
			}
		}
		catch(Exception e){
			//throw new OnlineBankingException("Account not yet Created");
		}
		return account;
	}

	@Override
	public ArrayList<OnlineBankingBean> getTransactionYear(int year) {
		ArrayList<OnlineBankingBean> yearlyTransactions=new ArrayList<OnlineBankingBean>();
		try{  
			//step2 create  the connection object  
			Connection con=DBUtil.obtainConnection();
			Statement stmt=con.createStatement();
			PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.YearlyTransactions);
			pmstmt.setInt(1, year);
			//System.out.println("hello");
			ResultSet rs=pmstmt.executeQuery();
			//System.out.println("hello");
			if(rs!=null){
				while(rs.next()){
					OnlineBankingBean b=new OnlineBankingBean();
					b.setTransactionId(rs.getLong(1));
					b.setTransactionDescription(rs.getString(2));
					b.setTransactionDate(rs.getString(3));
					b.setTransactionType(rs.getString(4));
					b.setTransactionAmount(rs.getLong(5));
					b.setAccountNo(rs.getLong(6));
					yearlyTransactions.add(b);
					
				}
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return yearlyTransactions;
	}
	@Override
	public ArrayList<OnlineBankingBean> getTransactionMonth(int month) {
		ArrayList<OnlineBankingBean> monthlyTransactions=new ArrayList<OnlineBankingBean>();
		try{  
			//step2 create  the connection object  
			Connection con=DBUtil.obtainConnection();
			Statement stmt=con.createStatement();
			PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.MonthlyTransactions);
			pmstmt.setInt(1, month);
			//System.out.println("hello");
			ResultSet rs=pmstmt.executeQuery();
			//System.out.println("hello");
			if(rs!=null){
				while(rs.next()){
					OnlineBankingBean b=new OnlineBankingBean();
					b.setTransactionId(rs.getLong(1));
					b.setTransactionDescription(rs.getString(2));
					b.setTransactionDate(rs.getString(3));
					b.setTransactionType(rs.getString(4));
					b.setTransactionAmount(rs.getLong(5));
					b.setAccountNo(rs.getLong(6));
					monthlyTransactions.add(b);
					
				}
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return monthlyTransactions;
	}
	@Override
	public ArrayList<OnlineBankingBean> getTransactionDate(int date) {
		ArrayList<OnlineBankingBean> dailyTransactions=new ArrayList<OnlineBankingBean>();
		try{  
			//step2 create  the connection object  
			Connection con=DBUtil.obtainConnection();
			Statement stmt=con.createStatement();
			PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.DailyTransactions);
			pmstmt.setInt(1, date);
			//System.out.println("hello");
			ResultSet rs=pmstmt.executeQuery();
			//System.out.println("hello");
			if(rs!=null){
				while(rs.next()){
					OnlineBankingBean b=new OnlineBankingBean();
					b.setTransactionId(rs.getLong(1));
					b.setTransactionDescription(rs.getString(2));
					b.setTransactionDate(rs.getString(3));
					b.setTransactionType(rs.getString(4));
					b.setTransactionAmount(rs.getLong(5));
					b.setAccountNo(rs.getLong(6));
					dailyTransactions.add(b);
					
				}
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return dailyTransactions;
	}

	@Override
	public ArrayList<Long> getAccountNumbers(long useri) throws OnlineBankingException {
		// TODO Auto-generated method stub
		Connection con=null;
		PreparedStatement st=null;
		ResultSet rs=null;
		long user_id=0;
ArrayList<Long> accounts=new ArrayList<Long>();
		
		try{
			
			con=DBUtil.obtainConnection();
			//stmt=con.createStatement();
			//rs=stmt.executeQuery("select account_no,user_id,login_password from user_table where user_id='"+userId+"' and login_password='"+password+"'");
			st=con.prepareStatement(IQueryMapper.payeeAccounts);
			st.setLong(1,useri);
			
			rs=st.executeQuery();
			
		
			if(rs!=null){
				while(rs.next()){
					
				user_id = rs.getLong(1);
				accounts.add(user_id);
					
				}
			}			
		}
		catch(OnlineBankingException e){
			throw new OnlineBankingException("details not fetched");
		}
		catch(Exception e){
			throw new OnlineBankingException("DataBase error");
		}
		return accounts;
	}


	@Override
	public boolean insertPayeeAccount(long user, long pid, String name) throws OnlineBankingException {
		// TODO Auto-generated method stub
		
		Connection con=null;
		PreparedStatement st=null;
		int rs=0;
		ArrayList<Long> arr=new ArrayList<Long>();
		int count=0;
boolean b = false;
ResultSet res=null;
		try{
			
			con=DBUtil.obtainConnection();
			
			//stmt=con.createStatement();
			//rs=stmt.executeQuery("select account_no,user_id,login_password from user_table where user_id='"+userId+"' and login_password='"+password+"'");
			st=con.prepareStatement(IQueryMapper.PayeeDetails);
			st.setLong(1,user);
			res=st.executeQuery();
			while(res.next())
			{
				
				long payee = res.getLong(2);
				if(pid==payee)
				{
					count=1;
				}
				
			}
			if(count==0)
			{
			st=con.prepareStatement(IQueryMapper.INSERTPAYEE);
			st.setLong(1,user);
			st.setLong(2,pid);
			st.setString(3, name);
			//System.out.println("hello before rs");
			rs=st.executeUpdate();
		System.out.println(rs);
		
			if(rs==1){
				
				b=true;
					
				}
						
		}
		
		else
		{
			System.out.println("hello in db");
			throw new OnlineBankingException("Payee already exists!!");
		}
		}
		catch(OnlineBankingException e){
			throw new OnlineBankingException("details not fetched");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return b;
	}

	@Override
	public ArrayList<Long> getAccountNo(long user) throws OnlineBankingException {
		Connection con=null;
		PreparedStatement st=null;
		ResultSet rs=null;
		ArrayList<Long> accno = null;

		try{
			
			con=DBUtil.obtainConnection();
			//stmt=con.createStatement();
			//rs=stmt.executeQuery("select account_no,user_id,login_password from user_table where user_id='"+userId+"' and login_password='"+password+"'");
			st=con.prepareStatement(IQueryMapper.GETACCOUNTNO);
			st.setLong(1, user);
		
			rs=st.executeQuery();
			
			
			if(rs!=null){
				while(rs.next()){
					
				accno.add(rs.getLong(1));
				}
			}			
		}
		catch(OnlineBankingException e){
			throw new OnlineBankingException("details not fetched");
		}
		catch(Exception e){
			throw new OnlineBankingException("DataBase error");
		}
		return accno;
	}

	@Override
	public ArrayList<Long> getpayee(long useri) throws OnlineBankingException {
		// TODO Auto-generated method stub
				Connection con=null;
				PreparedStatement st=null;
				ResultSet rs=null;
				long user_id=0;
		ArrayList<Long> accounts=new ArrayList<Long>();
				
				try{
					
					con=DBUtil.obtainConnection();
					//stmt=con.createStatement();
					//rs=stmt.executeQuery("select account_no,user_id,login_password from user_table where user_id='"+userId+"' and login_password='"+password+"'");
					st=con.prepareStatement(IQueryMapper.getpayee);
					st.setLong(1,useri);
					
					rs=st.executeQuery();
					
				
					if(rs!=null){
						while(rs.next()){
							
						user_id = rs.getLong(1);
						accounts.add(user_id);
							
						}
					}			
				}
				catch(OnlineBankingException e){
					throw new OnlineBankingException("details not fetched");
				}
				catch(Exception e){
					throw new OnlineBankingException("DataBase error");
				}
				return accounts;
			}

	@Override
	public ArrayList<Long> getuser(long useri) throws OnlineBankingException {
		Connection con=null;
		PreparedStatement st=null;
		ResultSet rs=null;
		long user_id=0;
ArrayList<Long> accounts=new ArrayList<Long>();
		
		try{
			
			con=DBUtil.obtainConnection();
			//stmt=con.createStatement();
			//rs=stmt.executeQuery("select account_no,user_id,login_password from user_table where user_id='"+userId+"' and login_password='"+password+"'");
			st=con.prepareStatement(IQueryMapper.getuser);
			st.setLong(1,useri);
			
			rs=st.executeQuery();
			
		
			if(rs!=null){
				while(rs.next()){
					
				user_id = rs.getLong(1);
				accounts.add(user_id);
					
				}
			}			
		}
		catch(OnlineBankingException e){
			throw new OnlineBankingException("details not fetched");
		}
		catch(Exception e){
			throw new OnlineBankingException("DataBase error");
		}
		return accounts;
	}

	@Override
	public boolean isValidPayee(long pid) throws OnlineBankingException {
		// TODO Auto-generated method stub
		
		Connection con=null;
		PreparedStatement st=null;
		int rs=0;
		ArrayList<Long> arr=new ArrayList<Long>();
		int count=0;
        boolean b = false;
        ResultSet res=null;
		try{
			
			con=DBUtil.obtainConnection();
			
			//stmt=con.createStatement();
			//rs=stmt.executeQuery("select account_no,user_id,login_password from user_table where user_id='"+userId+"' and login_password='"+password+"'");
			st=con.prepareStatement(IQueryMapper.getPayees);
			
			res=st.executeQuery();
			while(res.next())
			{
				
				long payee = res.getLong(1);
				if(pid==payee)
				{
					count=1;
				}
				
			}
			if(count==1)
			{
				b=true;
			
				}
						
		
		
		}
		catch(OnlineBankingException e){
			throw new OnlineBankingException("details not fetched");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return b;
	}

	@Override
	public ArrayList<OnlineBankingBean> getDetailedStatement(long account_no,
			String fromDate, String toDate) {
		Connection conn=null;
		PreparedStatement pmstmt=null;
		Statement stmt=null;
		ResultSet rs=null;
		 ArrayList<OnlineBankingBean> detailedStatement=new  ArrayList<OnlineBankingBean>();
		 System.out.println(fromDate);
		 System.out.println(toDate);
		try{
			conn=DBUtil.obtainConnection();
			stmt=conn.createStatement();
			rs=stmt.executeQuery("select * from transactions where account_no=? and to_");
			if(rs!=null){
				while(rs.next()){
					OnlineBankingBean b=new OnlineBankingBean();
					b.setAccountNo(rs.getLong("account_no"));
					b.setTransactionId(rs.getLong("transaction_id"));
					b.setTransactionType(rs.getString("transactionType"));
					b.setTransactionDate(rs.getString("dateoftransaction"));
					b.setTransactionDescription(rs.getString("trans_description"));
					b.setTransactionAmount(rs.getLong("tranAmount"));
					detailedStatement.add(b);
				}
			}
			
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return detailedStatement;
	}

		
		
		


}
