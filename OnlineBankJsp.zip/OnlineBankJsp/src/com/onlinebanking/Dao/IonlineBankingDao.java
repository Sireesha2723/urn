package com.onlinebanking.Dao;

import java.util.ArrayList;

import com.onlinebanking.Bean.OnlineBankingBean;

import Exception.OnlineBankingException;

public interface IonlineBankingDao {

	ArrayList<Long> getAccounts(long acc_no) throws OnlineBankingException;

	String getEmailId(long accountNo);

	String getEmailId(long acc_no, String email, String existingemail);

	String getAddress(long accountNo);

	String getAddressUpdate(long acc_no, String address, String existingAddress);

	String raiseCheckBookRequest(long accountNo, String description);

	ArrayList<OnlineBankingBean> getServiceRequestDetails(long service_id);

	ArrayList<Long> getPayeeAccounts(long uid);

	String transferFunds(long accountNo, long payeeAccount, String transferDesc,long amount,String transpwd);

	ArrayList<OnlineBankingBean> getAccountServiceRequestDetails(long acc_no);

	String createAccount(OnlineBankingBean ob);

	ArrayList<OnlineBankingBean> getTransactionYear(int year);
	ArrayList<OnlineBankingBean> getTransactionMonth(int month);

	ArrayList<OnlineBankingBean> getTransactionDate(int date);

	ArrayList<Long> getAccountNumbers(long useri) throws OnlineBankingException;

	boolean insertPayeeAccount(long user, long pid, String name) throws OnlineBankingException;

	ArrayList<Long> getAccountNo(long user) throws OnlineBankingException;

	ArrayList<Long> getpayee(long useri) throws OnlineBankingException;

	ArrayList<Long> getuser(long useri) throws OnlineBankingException;

	boolean isValidPayee(long pid) throws OnlineBankingException;

	ArrayList<OnlineBankingBean> getDetailedStatement(long account_no,
			String fromDate, String toDate);

	

}
