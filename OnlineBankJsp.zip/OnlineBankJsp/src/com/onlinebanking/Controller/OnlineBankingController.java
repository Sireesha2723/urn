package com.onlinebanking.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Exception.OnlineBankingException;

import com.onlinebanking.Bean.OnlineBankingBean;
import com.onlinebanking.Service.IonlineBankingService;
import com.onlinebanking.Service.OnlineBankingService;

/**
 * Servlet implementation class OnlineBankingController
 */
@WebServlet("/OnlineBankingController")
public class OnlineBankingController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OnlineBankingController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String operation=request.getParameter("action");
		System.out.println(operation);
		HttpSession session=request.getSession(true);
			
		if(operation!=null&&operation.equals("home")){
			long userId=Long.parseLong(request.getParameter("userId"));
			session.setAttribute("userid",userId);
			request.setAttribute("userId", userId);
			RequestDispatcher rd=null;
			rd=request.getRequestDispatcher("/home.jsp");
			rd.forward(request, response);
			
		}
		if(operation!=null&&operation.equalsIgnoreCase("DetailedStatement")){
			ArrayList<Long> accounts=new ArrayList<Long>();
			long acc_no=Long.parseLong(request.getParameter("userId"));
			IonlineBankingService ibs=new OnlineBankingService();
			try{
			accounts=ibs.getAccounts(acc_no);
			RequestDispatcher rd=null;
			request.setAttribute("accounts",accounts);
			rd=request.getRequestDispatcher("/DetailedStatement.jsp");
			rd.forward(request, response);
			}
			catch(Exception e){
				e.printStackTrace();
			}
			
		}
		if(operation!=null&&operation.equalsIgnoreCase("viewDetailedStatement")){
			long account_no=Long.parseLong(request.getParameter("accounts"));
			String fromDate=request.getParameter("fromDate");
			String toDate=request.getParameter("toDate");
			IonlineBankingService ibs=new OnlineBankingService();
			ArrayList<OnlineBankingBean> detailedStatement=ibs.getDetailedStatement(account_no,fromDate,toDate);
			System.out.println(detailedStatement);
			request.setAttribute("detailedStatement", detailedStatement);
			RequestDispatcher rd=request.getRequestDispatcher("/viewDetailedStatement.jsp");
			rd.forward(request, response);
		}
		if(operation!=null&&operation.equalsIgnoreCase("addPayee")){
			
			
			long useri=Long.parseLong(request.getParameter("userId"));
			//System.out.println(useri);
			RequestDispatcher rd1=null;
			IonlineBankingService ibs=new OnlineBankingService();
			ArrayList<Long> GetAccounts=new ArrayList<Long>();
			ArrayList<Long> GetUserAccounts=new ArrayList<Long>();
			try{
				GetAccounts=ibs.getAccountNumbers(useri);
			
		        GetUserAccounts = ibs.getAccounts(useri);
				request.setAttribute("users", GetUserAccounts);
				request.setAttribute("payeeid", GetAccounts);
			    System.out.println(GetAccounts);
			    System.out.println(GetUserAccounts);
				rd1=request.getRequestDispatcher("/addPayee.jsp");
				rd1.forward(request, response);
			}
			catch(OnlineBankingException e){
				System.out.println(e.getMessage());
			}
		}
		 if(operation!=null&&operation.equalsIgnoreCase("confirm")){
			 
			 boolean result;
			 long uacc=Long.parseLong(request.getParameter("userac"));
			 long pacc=Long.parseLong(request.getParameter("payeeac"));
			 String pname=request.getParameter("name");
			 String urn=request.getParameter("urn");
			 long userid=Long.parseLong(request.getParameter("userid"));
			 RequestDispatcher rd1=null;
			 IonlineBankingService ibs=new OnlineBankingService();
			 ArrayList<Long> GetUserAccounts=new ArrayList<Long>();
				ArrayList<Long> GetAccounts=new ArrayList<Long>();
				boolean b;
				boolean valid;
				try
				{
			 if(urn.equals("abc345"))
			 {
				 b=ibs.insertPayeeAccount(uacc,pacc,pname);
					if(b)
					{
								System.out.println("true");		
							GetAccounts=ibs.getpayee(userid);
							System.out.println(GetAccounts);
					        GetUserAccounts = ibs.getuser(userid);
					        System.out.println(GetUserAccounts);
							request.setAttribute("UserAccounts", GetUserAccounts);
							request.setAttribute("PayeeAccounts", GetAccounts);
							request.setAttribute("userId", uacc);
							rd1=request.getRequestDispatcher("/FundTransfer.jsp");
							rd1.forward(request, response);
						
					}
					}
					else{
					request.setAttribute("users", GetUserAccounts);
					session.setAttribute("error","wrongpayee");
					rd1=request.getRequestDispatcher("/addPayee.jsp");
					rd1.forward(request, response);
					
				}
				 
			 }
		 
		 catch(Exception e){
				System.out.println(e.getMessage());
			} 
			 
		 }
		
     if(operation!=null&&operation.equalsIgnoreCase("insertPayee")){
    	 	long useri=Long.parseLong(request.getParameter("usersid"));
			long pid=Long.parseLong(request.getParameter("payeeAccount"));
			String name=request.getParameter("name");
			long userid=Long.parseLong(request.getParameter("userid"));
			RequestDispatcher rd1=null;
			IonlineBankingService ibs=new OnlineBankingService();
			ArrayList<Long> GetUserAccounts=new ArrayList<Long>();
			ArrayList<Long> GetAccounts=new ArrayList<Long>();
			boolean b;
			boolean valid;
			try{
				
				valid=ibs.isValidPayee(pid);
				if(valid)
				{
					String testu=""+useri;
					String testp=""+pid;
					String test=""+userid;
					request.setAttribute("userac", testu);
					request.setAttribute("payeeac",testp);
					request.setAttribute("name",name);
					request.setAttribute("userid",userid);
					rd1=request.getRequestDispatcher("/UrnConfirm.jsp");
					rd1.forward(request, response);
				   /* b=ibs.insertPayeeAccount(useri,pid,name);
				if(b)
				{
									
						GetAccounts=ibs.getpayee(userid);
						System.out.println(GetAccounts);
				        GetUserAccounts = ibs.getuser(userid);
				        System.out.println(GetUserAccounts);
						request.setAttribute("UserAccounts", GetUserAccounts);
						request.setAttribute("PayeeAccounts", GetAccounts);
						request.setAttribute("userId", useri);
						rd1=request.getRequestDispatcher("/FundTransfer.jsp");
						rd1.forward(request, response);
					
				}*/
				}
				else
				request.setAttribute("users", GetUserAccounts);
				session.setAttribute("error","wrongpayee");
				rd1=request.getRequestDispatcher("/addPayee.jsp");
				rd1.forward(request, response);
				
			}
			catch(Exception e){
				System.out.println(e.getMessage());
			}
			//out.println(userId);
		}
		if(operation!=null&&operation.equalsIgnoreCase("updateEmail")){
			//IonlineBankingService ibs=new OnlineBankingService();
			long acc_no=Long.parseLong(request.getParameter("userId"));
			System.out.println(acc_no);
			IonlineBankingService ibs=new OnlineBankingService();
			ArrayList<Long> accounts=new ArrayList<Long>();
			try{
			accounts=ibs.getAccounts(acc_no);
			RequestDispatcher rd=null;
			request.setAttribute("accounts",accounts);
			rd=request.getRequestDispatcher("/UpdateEmail.jsp");
			rd.forward(request, response);
			}
			catch(OnlineBankingException e){
				System.out.println(e.getMessage());
			}
			
		}
		if(operation!=null&&operation.equalsIgnoreCase("EmailUpdate")){
			long accountNo=Long.parseLong(request.getParameter("accountNo"));
			System.out.println(accountNo);
			IonlineBankingService ibs=new OnlineBankingService();
			String email=ibs.getEmailId(accountNo);
			request.setAttribute("emailId", email);
			request.setAttribute("accountNo", accountNo);
			RequestDispatcher rd=null;
			rd=request.getRequestDispatcher("/EmailUpdation.jsp");
			rd.forward(request, response);
		}
		if(operation!=null&&operation.equalsIgnoreCase("ChangeEmail")){
			String email=request.getParameter("emailId");
			long acc_no=Long.parseLong(request.getParameter("accNo"));
			String existingemail=request.getParameter("existingemail");
			//System.out.println(email);
			//System.out.println(acc_no);
			//System.out.println(existingemail)
			IonlineBankingService ibs=new OnlineBankingService();
			String updateEmail=ibs.updateEmail(acc_no,email,existingemail);
			if(updateEmail.equalsIgnoreCase("Updated")){
					RequestDispatcher rd=null;
					PrintWriter out=response.getWriter();
					out.println("updateEmail");
					rd=request.getRequestDispatcher("/EmailUpdation.jsp");
			}
			
			
		}
		else if(operation!=null&&operation.equalsIgnoreCase("updateAddress")){
			long acc_no=Long.parseLong(request.getParameter("userId"));
			System.out.println(acc_no);
			IonlineBankingService ibs=new OnlineBankingService();
			ArrayList<Long> accounts=new ArrayList<Long>();
			try{
			accounts=ibs.getAccounts(acc_no);
			RequestDispatcher rd=null;
			request.setAttribute("accountNumbers",accounts);
			rd=request.getRequestDispatcher("/UpdateAddress.jsp");
			rd.forward(request, response);
			}
			catch(OnlineBankingException e){
				System.out.println(e.getMessage());
			}
		}
		if(operation!=null&&operation.equalsIgnoreCase("AddressUpdate")){
			long accountNo=Long.parseLong(request.getParameter("accountNo"));
			System.out.println(accountNo);
			IonlineBankingService ibs=new OnlineBankingService();
			String address=ibs.getAddress(accountNo);
			request.setAttribute("Address", address);
			request.setAttribute("accountNo", accountNo);
			RequestDispatcher rd=null;
			rd=request.getRequestDispatcher("/AddressUpdation.jsp");
			rd.forward(request, response);
		}
		if(operation!=null&&operation.equalsIgnoreCase("ChangeAddress")){
			String address=request.getParameter("Address");
			long acc_no=Long.parseLong(request.getParameter("accNo"));
			String existingAddress=request.getParameter("existingAddress");
			//System.out.println(email);
			//System.out.println(acc_no);
			//System.out.println(existingemail)
			IonlineBankingService ibs=new OnlineBankingService();
			String updateAddress=ibs.updateAddress(acc_no,address,existingAddress);
			if(updateAddress.equalsIgnoreCase("Updated")){
					RequestDispatcher rd=null;
					PrintWriter out=response.getWriter();
					out.println("updateAddress");
					rd=request.getRequestDispatcher("/AddressUpdation.jsp");
			}
			
			
		}
		if(operation!=null&&operation.equalsIgnoreCase("RequestforCheckBook")){
			long acc_no=Long.parseLong(request.getParameter("userId"));
			System.out.println(acc_no);
			IonlineBankingService ibs=new OnlineBankingService();
			ArrayList<Long> accounts=new ArrayList<Long>();
			try{
			accounts=ibs.getAccounts(acc_no);
			RequestDispatcher rd=null;
			request.setAttribute("accounts",accounts);
			rd=request.getRequestDispatcher("/CheckBookAccounts.jsp");
			rd.forward(request, response);
			}
			catch(OnlineBankingException e){
				System.out.println(e.getMessage());
			}
		}
		if(operation!=null&&operation.equalsIgnoreCase("RaiseRequest")){
			long accountNo=Long.parseLong(request.getParameter("account"));
			String description=request.getParameter("description");
			IonlineBankingService ibs=new OnlineBankingService();
			String raiseCheckBookRequest=ibs.raiseCheckBookRequest(accountNo,description);
			request.setAttribute("checkBookRequest", raiseCheckBookRequest);
			RequestDispatcher rd=null;
			rd=request.getRequestDispatcher("/CheckBookService.jsp");
			rd.forward(request, response);
		}
		if(operation!=null&&operation.equalsIgnoreCase("TrackCheckBookRequest")){
			RequestDispatcher rd=null;
			long userId=Long.parseLong(request.getParameter("userId"));
			request.setAttribute("userId", userId);
			rd=request.getRequestDispatcher("/TrackCheckBookRequest.jsp");
			rd.forward(request, response);
		}
		if(operation!=null&&operation.equalsIgnoreCase("TrackService")){
			RequestDispatcher rd=null;
			IonlineBankingService ibs=new OnlineBankingService();
			long service_id=Long.parseLong(request.getParameter("serviceId"));
			ArrayList<OnlineBankingBean> serviceRequestDetails=new ArrayList<OnlineBankingBean>();
			serviceRequestDetails=ibs.getCheckBookService(service_id);
			request.setAttribute("checkBookDetails", serviceRequestDetails);
			rd=request.getRequestDispatcher("/ServiceRequestDetails.jsp");
			rd.forward(request, response);
		}
		if(operation!=null&&operation.equalsIgnoreCase("fundTransfer")){
			String userId=request.getParameter("userId");
			long uid=Long.parseLong(userId);
			RequestDispatcher rd=null;
			IonlineBankingService ibs=new OnlineBankingService();
			ArrayList<Long> GetAccounts=new ArrayList<Long>();
			ArrayList<Long> PayeeAccounts=new ArrayList<Long>();
			try{
				GetAccounts=ibs.getAccounts(uid);
				PayeeAccounts=ibs.getPayeeAccounts(uid);
				request.setAttribute("UserAccounts", GetAccounts);
				request.setAttribute("PayeeAccounts", PayeeAccounts);
				request.setAttribute("userId", uid);
				rd=request.getRequestDispatcher("/FundTransfer.jsp");
				rd.forward(request, response);
			}
			catch(OnlineBankingException e){
				System.out.println(e.getMessage());
			}
			//out.println(userId);
		}
		if(operation!=null&operation.equalsIgnoreCase("transferFunds")){
			long accountNo=Long.parseLong(request.getParameter("UserAccounts"));
			long payeeAccount=Long.parseLong(request.getParameter("PayeeAccount"));
			String transferDesc=request.getParameter("transferDesc");
			long amount=Long.parseLong(request.getParameter("fund"));
			String transpwd=request.getParameter("transpwd");
			IonlineBankingService ibs=new OnlineBankingService();
			String fundTransfer=ibs.transferFunds(accountNo,payeeAccount,transferDesc,amount,transpwd);
			if(fundTransfer.equalsIgnoreCase("success")){
			request.setAttribute("transferFund", fundTransfer);
			RequestDispatcher rd=request.getRequestDispatcher("/Success.jsp");
			rd.forward(request, response);
			}
			else{
				System.out.println("fund transfer failed");
			}
		}
		if(operation!=null&&operation.equalsIgnoreCase("TrackRequestOnAcount")){
			long uid=Long.parseLong(request.getParameter("userId"));
			//System.out.println(uid);
			
			//GetAccounts=ibs.getAccounts(userId);
			RequestDispatcher rd=null;
			IonlineBankingService ibs=new OnlineBankingService();
			ArrayList<Long> GetAccounts=new ArrayList<Long>();
			try{
				GetAccounts=ibs.getAccounts(uid);
				request.setAttribute("UserAccounts", GetAccounts);
				rd=request.getRequestDispatcher("/TrackServiceByAccount.jsp");
				rd.forward(request, response);
			}
			catch(OnlineBankingException e){
				System.out.println(e.getMessage());
			}
		}
		if(operation!=null&&operation.equalsIgnoreCase("trackServiceRequest")){
			long acc_no=Long.parseLong(request.getParameter("UserAccounts"));
			System.out.println(acc_no);
			IonlineBankingService ibs=new OnlineBankingService();
			ArrayList<OnlineBankingBean> serviceRequestDetails=new ArrayList<OnlineBankingBean>();
			serviceRequestDetails=ibs.getCheckBookAccountService(acc_no);
			RequestDispatcher rd=null;
			request.setAttribute("checkBookDetails", serviceRequestDetails);
			rd=request.getRequestDispatcher("/AccountServiceRequestDetails.jsp");
			rd.forward(request, response);
		}
		if(operation!=null&&operation.equalsIgnoreCase("createAccounts")){
			RequestDispatcher rd=null;
			rd=request.getRequestDispatcher("/createNewAccounts.jsp");
			rd.forward(request, response);
		}
		if(operation!=null&&operation.equalsIgnoreCase("viewTransactions")){
			RequestDispatcher rd=null;
			rd=request.getRequestDispatcher("/viewTransactions.jsp");
			rd.forward(request, response);
		}
		if(operation!=null&&operation.equalsIgnoreCase("viewBlockedAccounts")){
			RequestDispatcher rd=null;
			rd=request.getRequestDispatcher("/viewBlockedAccounts.jsp");
			rd.forward(request, response);
		}
		if(operation!=null&&operation.equalsIgnoreCase("CreateAccount")){
			String name=request.getParameter("cname");
			String address=request.getParameter("address");
			String email=request.getParameter("emailId");
			String accountType=request.getParameter("Accounttype");
			long balance=Long.parseLong(request.getParameter("balance"));
			String panno=request.getParameter("panno");
			OnlineBankingBean ob=new OnlineBankingBean();
			ob.setName(name);
			ob.setAddress(address);
			ob.setEmailId(email);
			ob.setAccountType(accountType);
			ob.setOpeningBalance(balance);
			ob.setPanno(panno);
			IonlineBankingService ibs=new OnlineBankingService();
			String createAccount=ibs.createAccount(ob);
			if(createAccount!=null){
				PrintWriter out=response.getWriter();
				out.println("Account Created Successfully with Account no"+createAccount);
			}
			else{
				System.out.println("Account not created");
			}
			
		}
		if(operation!=null&&operation.equalsIgnoreCase("viewTransactionHistory")){
			String option=request.getParameter("viewTransactions");
			RequestDispatcher rd=null;
			if(option.equals("YearlyTransactions")){
				   int year = Calendar.getInstance().get(Calendar.YEAR);
				   //System.out.println(year);
				   ArrayList<OnlineBankingBean> transactionYear=new ArrayList<OnlineBankingBean>();
				   IonlineBankingService ibs=new OnlineBankingService();
				   transactionYear=ibs.getYearlyTransaction(year);
				  // System.out.println(transactionYear);
				   request.setAttribute("Transactions", transactionYear);
				   request.setAttribute("TransactionHistory", "Yearly Transactions");
				   rd=request.getRequestDispatcher("/transactionHistory.jsp");
				   rd.forward(request, response);
			}
			else if(option.equals("MonthlyTransactions")){
				int month = Calendar.getInstance().get(Calendar.MONTH);
				ArrayList<OnlineBankingBean> transactionMonth=new ArrayList<OnlineBankingBean>();
				IonlineBankingService ibs=new OnlineBankingService();
				transactionMonth=ibs.getMonthlyTransaction(month);
				request.setAttribute("Transactions", transactionMonth);
				request.setAttribute("TransactionHistory", "Monthly Transactions");
				rd=request.getRequestDispatcher("/transactionHistory.jsp");
				rd.forward(request, response);
				
			}
			else if(option.equals("DailyTransactions")){
				int date = Calendar.getInstance().get(Calendar.DATE);
				ArrayList<OnlineBankingBean> transactionDate=new ArrayList<OnlineBankingBean>();
				IonlineBankingService ibs=new OnlineBankingService();
				transactionDate=ibs.getDailyTransaction(date);
				request.setAttribute("Transactions", transactionDate);
				request.setAttribute("TransactionHistory", "Daily Transactions");
				rd=request.getRequestDispatcher("/transactionHistory.jsp");
				rd.forward(request, response);
				
			}
			
			
		}
		
	}

	private long getAccountNo(long user) {
		// TODO Auto-generated method stub
		return 0;
	}

}
